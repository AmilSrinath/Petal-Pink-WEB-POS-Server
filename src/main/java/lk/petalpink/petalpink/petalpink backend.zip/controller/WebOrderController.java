package lk.petalpink.petalpink.controller;

import lk.petalpink.petalpink.dto.website.*;
import lk.petalpink.petalpink.service.WebOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/website/order")
@CrossOrigin(origins = "*")
public class WebOrderController {

    @Autowired
    private WebOrderService webOrderService;

    /**
     * POST /api/website/order/place
     * Frontend Checkout page calls this to save the order.
     * Returns { "orderRef": "PP-843021" }
     */
    @PostMapping("/place")
    public ResponseEntity<Map<String, String>> placeOrder(
            @RequestBody WebsiteSaveOrderRequestDTO req) {
        String orderRef = webOrderService.placeOrder(req);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(Map.of("orderRef", orderRef));
    }

    /**
     * GET /api/website/order/all
     * Admin panel: list all web orders (header only).
     */
    @GetMapping("/all")
    public ResponseEntity<List<WebsiteOrderDTO>> getAllOrders() {
        return ResponseEntity.ok(webOrderService.getAllOrders());
    }

    /**
     * GET /api/website/order/{orderRef}
     * Admin panel: full detail for one order.
     */
    @GetMapping("/details/{orderRef}")
    public ResponseEntity<?> getOrderDetails(@PathVariable String orderRef) {
        WebsiteOrderDetailsResponseDTO detail = webOrderService.getOrderDetails(orderRef);
        if (detail == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Order not found: " + orderRef));
        }
        return ResponseEntity.ok(detail);
    }
}
